import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { Fragment } from 'react';
import {useState,useEffect} from 'react'

import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import { TextField } from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import axios from 'axios';

export default function LabTabs() {
  const [value, setValue] = React.useState('1');

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const label = { inputProps: { 'aria-label': 'Checkbox demo' } };
  const StyledTableCell = styled(TableCell)(({ theme }) => ({
      [`&.${tableCellClasses.head}`]: {
        backgroundColor: theme.palette.common.black,
        color: theme.palette.common.white,
      },
      [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
      },
    }));
    
    const StyledTableRow = styled(TableRow)(({ theme }) => ({
      '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
      },
      // hide last border
      '&:last-child td, &:last-child th': {
        border: 0,
      },
    }));

    

    const handleEdit= (id) =>{
        
    alert(id);
    }
    const handleDelete= (id) =>{
        if(window.confirm("Are you sure you want to delete") == true ){
            debugger
            alert(id);

            const url =`https://localhost:7265/api/Employees/delEmp/${id}`;

            axios.delete(url).then((result) => {
                debugger;
                if (result.data == '111') {
                  debugger;
                  alert("Deleted successfully");
          
                }
                else{
                    alert("something went wrong");
                }
          
              }).catch((ex) => {
          
                alert(ex.message);
                
              })
        }
       
        }
        const handleADD= () =>{
            debugger;
            const data = {
                name:Name,
                email:email,
              
            };
            const url ='https://localhost:7265/api/Employees/AddEmp';

            axios.post(url, data).then((result) => {
                debugger;
                if (result.data == 'Registerd Successfully...') {
                  debugger;
                  alert("Registered successfully");
          
                }
          
              }).catch((ex) => {
          
                alert(ex.message);
                
              })


            }


        const [Name,setName] = useState();
        const [email,setEmail] = useState();
       



        const [data,setData]= useState([]);

        useEffect(()=>{
            getData();
        },[])
    
        const getData = () => {
            debugger;
            axios.get('https://localhost:7201/api/Students/GetStudents')
              .then((result) => {
                debugger;
                setData(result.data)
                
              })
              .catch((error) => {
                console.log(error)
              })
          }
    




  return (
    <Box sx={{ width: '100%', typography: 'body1' }}>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <TabList onChange={handleChange} aria-label="lab API tabs example">
            <Tab label="Students" value="1" />
            <Tab label="Courses" value="2" />
            <Tab label="Enrollment" value="3" />
          </TabList>
        </Box>
        {/* students */}
        <TabPanel value="1"> 
        <Fragment>
     <TableContainer component={Paper}>
     <TableRow>
        <TableCell>
            <TextField id="NAME" placeholder='Enter Name' value={Name} onChange={(e)=>setName(e.target.value)} ></TextField>
        </TableCell>

        <TableCell>
            <TextField id="EMAIL" placeholder='Enter Email' value={email} onChange={(e)=>setEmail(e.target.value)}></TextField>
        </TableCell>

        <TableCell>
        <Button variant="contained" color="success"  onClick={()=>handleADD()}>ADD</Button> 
        </TableCell>
     </TableRow>
     </TableContainer>
     
<TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell align="center">#</StyledTableCell>
            <StyledTableCell align="center">Name</StyledTableCell>
            <StyledTableCell align="center">Email</StyledTableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
        {
            data && data.length > 0 ?
            data.map((item,index)=>{
                return(
                    <StyledTableRow key={index }>
                        <StyledTableCell align="center">{index+1}</StyledTableCell>
                    <StyledTableCell align="center">{item.name}</StyledTableCell>
                    <StyledTableCell align="center">{item.email}</StyledTableCell>
                    <StyledTableCell align="center" colSpan={6}>
                    <Button variant="contained" color="success" onClick={()=>handleEdit(item.id)}>EDIT</Button> 
        
                    <Button variant="contained" color="errors" onClick={()=>handleDelete(item.id)}>DELETE</Button></StyledTableCell> 
                  </StyledTableRow>
                )
            }) 
            :
            'Loading......!!'
        }
          
        </TableBody>
      </Table>
    </TableContainer>
    </Fragment>

            </TabPanel>
            {/* courses */}
        <TabPanel value="2">
        <Fragment>
    
     
<TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
            <StyledTableCell align="center">#</StyledTableCell>
            <StyledTableCell align="center">COURSE NAME</StyledTableCell>
            <StyledTableCell align="center">DESCRIPTION</StyledTableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
        {
            data && data.length > 0 ?
            data.map((item,index)=>{
                return(
                    <StyledTableRow key={index }>
                        <StyledTableCell align="center">{index+1}</StyledTableCell>
                    <StyledTableCell align="center">{item.name}</StyledTableCell>
                    <StyledTableCell align="center">{item.email}</StyledTableCell>
                    <StyledTableCell align="center" colSpan={6}>
                    <Button variant="contained" color="success" onClick={()=>handleEdit(item.id)}>EDIT</Button> 
        
                    <Button variant="contained" color="errors" onClick={()=>handleDelete(item.id)}>DELETE</Button></StyledTableCell> 
                  </StyledTableRow>
                )
            }) 
            :
            'Loading......!!'
        }
          
        </TableBody>
      </Table>
    </TableContainer>
    </Fragment>
            </TabPanel>
            {/* enrollment */}
        <TabPanel value="3">
        <Fragment>
    
     
    <TableContainer component={Paper}>
          <Table sx={{ minWidth: 700 }} aria-label="customized table">
            <TableHead>
              <TableRow>
                <StyledTableCell align="center">#</StyledTableCell>
                <StyledTableCell align="center">STUDENTID</StyledTableCell>
                <StyledTableCell align="center">COURSE ID</StyledTableCell>
                <StyledTableCell align="center">ENROLLMENT DATE</StyledTableCell>
                
              </TableRow>
            </TableHead>
            <TableBody>
            {
                data && data.length > 0 ?
                data.map((item,index)=>{
                    return(
                        <StyledTableRow key={index }>
                            <StyledTableCell align="center">{index+1}</StyledTableCell>
                        <StyledTableCell align="center">{item.name}</StyledTableCell>
                        <StyledTableCell align="center">{item.email}</StyledTableCell>
                        <StyledTableCell align="center" colSpan={6}>
                        <Button variant="contained" color="success" onClick={()=>handleEdit(item.id)}>EDIT</Button> 
            
                        <Button variant="contained" color="errors" onClick={()=>handleDelete(item.id)}>DELETE</Button></StyledTableCell> 
                      </StyledTableRow>
                    )
                }) 
                :
                'Loading......!!'
            }
              
            </TableBody>
          </Table>
        </TableContainer>
        </Fragment></TabPanel>
      </TabContext>
    </Box>
  );
}