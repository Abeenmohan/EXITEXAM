﻿using exitexamBackend.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace exitexamBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoursesController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public CoursesController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetCourses")]

        public List<Course> Getcourses()

        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("Default_connection").ToString());


            SqlDataAdapter da = new SqlDataAdapter("Proc_get_course_dtls", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);


            List<Course> list = new List<Course>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Course cour = new Course();
                    cour.Title = dt.Rows[i]["Title"].ToString();
                    cour.Description = dt.Rows[i]["Description"].ToString();
                    list.Add(cour);


                }
            }
            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        [HttpPost]
        [Route("AddCourses")]
        public string AddCoour(Course course)
        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("Default_connection").ToString());
            string msg;

            SqlCommand cmd = new SqlCommand("proc_add_courses", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Title", course.Title);
            cmd.Parameters.AddWithValue("@Description", course.Description);


            conn.Open();
            int i = cmd.ExecuteNonQuery();
            conn.Close();

            if (i > 0)
            {
                msg = "Course added Successfully...";
            }
            else
            {
                msg = "Error.";
            }
            return msg;
        }
    }
}
