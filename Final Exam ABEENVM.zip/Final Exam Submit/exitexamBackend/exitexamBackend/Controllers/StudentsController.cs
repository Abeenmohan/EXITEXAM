﻿using exitexamBackend.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Win32;
using System.Data;

namespace exitexamBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public StudentsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetStudents")]

        public List<Student> GetStudents()

        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("Default_connection").ToString());


            SqlDataAdapter da = new SqlDataAdapter("Proc_get_student_dtls", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);

            
            List<Student> list = new List<Student>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Student Stud = new Student();
                    Stud.Name = dt.Rows[i]["Name"].ToString();
                    Stud.Email = dt.Rows[i]["Email"].ToString();
                    list.Add(Stud);


                }
            }
            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        [HttpPost]
        [Route("AddStudents")]
        public string Addstud(Student student)
        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("Default_connection").ToString());
            string msg;

            SqlCommand cmd = new SqlCommand("proc_add_student2", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Name", student.Name);
            cmd.Parameters.AddWithValue("@Email", student.Email);


            conn.Open();
            int i = cmd.ExecuteNonQuery();
            conn.Close();

            if (i > 0)
            {
                msg = "Registerd Successfully...";
            }
            else
            {
                msg = "Error.";
            }
            return msg;
        }
    }
}
