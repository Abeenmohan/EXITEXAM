﻿using exitexamBackend.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System;
using System.Data;

namespace exitexamBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnrollmentsController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public EnrollmentsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("Enrolldtl")]

        public List<Enrollment> GetEnrolldtl()

        {
            SqlConnection conn = new SqlConnection(_configuration.GetConnectionString("Default_connection").ToString());


            SqlDataAdapter da = new SqlDataAdapter("Proc_get_enroll_dtls", conn);

            DataTable dt = new DataTable();
            da.Fill(dt);


            List<Enrollment> list = new List<Enrollment>();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Enrollment enr = new Enrollment();
                    enr.StudentId = Convert.ToInt32(dt.Rows[i]["StudentId"]);
                    enr.CourseId = Convert.ToInt32(dt.Rows[i]["CourseId"]);
                    enr.EnrollmentDate = Convert.ToDateTime(dt.Rows[i]["EnrollmentDate"]);
                    list.Add(enr);


                }
            }
            if (list.Count > 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        
    }
}
